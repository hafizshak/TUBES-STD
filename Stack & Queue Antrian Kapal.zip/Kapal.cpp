#include "Header.h"

adr_kapal create_element(kapal k){
	adr_kapal pk = new elm_kapal;
	info(pk) = k;
	next(pk) = NULL;
	
	return pk;
}

bool isQueueEmpty(Queue Q){
	return Head(Q) == NULL;
}

void createQueue(Queue &Q){
	Head(Q) = NULL;
	Tail(Q) = NULL;
}

void enqueue(Queue &Q, kapal k){
	adr_kapal pk = create_element(k);
	if(Head(Q) == NULL){
		Head(Q) = pk;
		Tail(Q) = pk;
	}else{
		Stack S;
		createStack(S);
		while(Head(Q) != NULL && info(Head(Q)).kapasitas > k.kapasitas){
			push(S, dequeue(Q));
		}
		
		if(Head(Q) == NULL){
			Head(Q) = pk;
			Tail(Q) = pk;
		}else{
			next(pk) = Head(Q);
			Head(Q) = pk;
		}
		
		while(!isStackEmpty(S)){
			kapal ktemp = pop(S);
			adr_kapal pktemp = create_element(ktemp);
			next(pktemp) = Head(Q);
			Head(Q) = pktemp;
		}
	}
}

kapal dequeue(Queue &Q){
	kapal k;
	if(Head(Q) != NULL){
		adr_kapal del = Head(Q);
		k = info(Head(Q));
		Head(Q) = next(Head(Q));
		delete del;
	}
	return k;
}

void showQueue(Queue Q){
	adr_kapal curr = Head(Q);
	int i = 0;
	cout << "\t\t\tAntrean Kapal :" << endl;
	while(curr != NULL){
		i += 1;
		cout << "\t\t\t";
		cout << i << ". " << info(curr).nama << " (" << info(curr).kapasitas << " penumpang)" << endl;
		curr = next(curr);
	}
}

bool isStackEmpty(Stack S){
	return Top(S) == NULL;
}

void createStack(Stack &S){
	Top(S) = NULL;
}

void push(Stack &S, kapal k){
	adr_kapal pk = create_element(k);
	next(pk) = Top(S);
	Top(S) = pk;
}

kapal pop(Stack &S){
	kapal k;
	if(!isStackEmpty(S)){
		adr_kapal del = Top(S);
		k = info(Top(S));
		Top(S) = next(Top(S));
		delete del;
	}
	return k;
}
